import React from "react";
import { Layout } from "antd";
import { AiOutlineSearch } from "react-icons/ai";
import "./style.css";
import Links from "../tools/links";
import Posts from "../tools/posts";

const { Header, Footer, Sider, Content } = Layout;

export default function Index() {
  return (
    <Layout>
      <Sider
        collapsible={true}
        className="siderContainer"
        width={300}
        theme="light"
      >
        <Links />
      </Sider>
      <Layout>
        <Header style={{ backgroundColor: "#fff" }}>
          <div className="test">
            <ul className="headerListContainer">
              <li>
                <p>Эхлэл</p>
              </li>
              <li
                onClick={() => {
                  window.scrollTo({
                    top: document.body.scrollHeight,
                    left: 0,
                    behavior: "smooth",
                  });
                }}
              >
                <p>Программууд</p>
              </li>
            </ul>
          </div>
        </Header>
        <Content style={{ backgroundColor: "#fff" }}>
          <div className="contentContainer">
            <div className="searchContainer">
              <p>Эрчим хүчний салбарын нэгдсэн мэдээлэл</p>
              <div style={{ position: "relative", paddingLeft: "20%" }}>
                <input type="text" placeholder="Search" />
                <button>
                  <AiOutlineSearch className="searchIcon" />
                </button>
              </div>
            </div>
            <div style={{ flex: 1.8, paddingLeft: "5%" }}>
              <img
                alt="title"
                src={require("./../../assets/theme/clean-energy-vs-green-energy.png")}
                style={{ width: "100%" }}
              />
            </div>
          </div>
          <Posts />
        </Content>
        <Footer style={{ backgroundColor: "#fff" }}>
          <ul className="footerListContainer">
            <li>И-Оффис</li>
            <li>Диспетчерийн хоногийн мэдээ</li>
            <li>Тэг үлдэгдэлтэй данс</li>
            <li>Электрон шуудан</li>
            <li>Технологийн зөрчил</li>
            <li>Зөвлөл</li>
          </ul>
        </Footer>
      </Layout>
    </Layout>
  );
}
