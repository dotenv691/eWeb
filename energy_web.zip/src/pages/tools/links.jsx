import React from "react";
import "./style.css";
import datas from "./datas.json";

export default function Links() {
  return (
    <div style={{ paddingBottom: 20 }}>
      {datas.map((el, key) => (
        <div key={key} className="linksFlex">
          <div className="logo">
            <img alt={el.title} src={el.img} />
          </div>
          <p className="title">{el.title.toUpperCase()}</p>
        </div>
      ))}
    </div>
  );
}
