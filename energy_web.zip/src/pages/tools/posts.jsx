import React from "react";
import "./style.css";
import datas from "./postData.json";

export default function Posts() {
  return (
    <div className="postsContainer">
      {datas.map((el, key) => (
        <div className="singlePostContainer" key={key}>
          <h5>{el.title}</h5>
          <p>{el.desc}</p>
          <button>Press</button>
        </div>
      ))}
    </div>
  );
}
