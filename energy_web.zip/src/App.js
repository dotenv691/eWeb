import { BrowserRouter, Switch } from "react-router-dom";
// Custom RouteLink
import { RouteLink } from "./route/routeLink";

// Ашиглагдаж байгаа хуудсуудыг оруулж ирэх
import HomePage from "./pages/home";
import NotFound from "./pages/notFound";

export default function App() {
  return (
    <BrowserRouter forceRefresh={true}>
      <Switch>
        <RouteLink exact path="/" component={HomePage} />

        {/* Not Found хуудас */}
        <RouteLink exact path="*" component={NotFound} />
      </Switch>
    </BrowserRouter>
  );
}
